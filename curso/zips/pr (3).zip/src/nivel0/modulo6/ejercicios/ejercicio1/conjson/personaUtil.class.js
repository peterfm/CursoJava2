			function PersonaUtil() {
				var personas = [];
				var contador = 1;
	
				var buscarPos = function(id) {
					for (var i = 0; i < personas.length; i++) {
						if (personas[i].id == id) 
							return i;
					}

					return null;
				};

				this.modificar = function(p) {
					var pos = buscarPos(p.id);
					if (pos != null)
						personas[pos] = p;
				};

				this.eliminar = function(id) {
					var pos = buscarPos(id);
					if (pos != null)
						personas.splice(pos, 1);
				};

				this.obtener = function(id) {
					var pos = buscarPos(id);
					if (pos != null)
						return personas[pos];
					else
						return null;
				};

				this.agregar = function(p) {
					p.id = contador++;
					personas[personas.length] = p;
				};

				this.obtenerTodos = function() {
					return personas;
				};
			}

