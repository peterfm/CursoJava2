			function Persona(_nombre, _apellido, _fnac, _altura) {
				var id;
				var nombre = _nombre;
				var apellido = _apellido;
				var fechaNacimiento = _fnac;
				var altura = _altura;

				this.setId = function(i) { id = i; }
				this.getId = function() { return id; }
				this.setNombre = function(n) { nombre = n; }
				this.getNombre = function() { return nombre; }
				this.setApellido = function(a) { apellido = a; }
				this.getApellido = function() { return apellido; }
				this.setFechaNacimiento = function(f) { fechaNacimiento = f; }
				this.getFechaNacimiento = function() { return fechaNacimiento; }
				this.setAltura = function(a) { altura = a; }
				this.getAltura = function() { return altura; }

				this.toString = function() {
					return "[id = " + id +
						", nombre = " + nombre +
						", apellido = " + apellido +
						", fechaNacimiento = " + fechaNacimiento +
						", altura = " + altura + "]";
				}
			}

