var personaUtil = {
	personas: [],
	contador: 1,
	buscarPos: function(id) {
					for (var i = 0; i < this.personas.length; i++) {
						if (this.personas[i].id == id) 
							return i;
					}

					return null;
				},

	modificar: function(p) {
					var pos = this.buscarPos(p.id);
					if (pos != null)
						this.personas[pos] = p;
				},

	eliminar: function(id) {
					var pos = this.buscarPos(id);
					if (pos != null)
						this.personas.splice(pos, 1);
				},

	obtener: function(id) {
					var pos = this.buscarPos(id);
					if (pos != null)
						return this.personas[pos];
					else
						return null;
				},

	agregar: function(p) {
					p.id = this.contador++;
					this.personas[this.personas.length] = p;
				},

	obtenerTodos: function() {
					return this.personas;
				}
}

