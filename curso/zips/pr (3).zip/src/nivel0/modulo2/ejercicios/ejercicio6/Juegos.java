public class Juegos {}

interface JuegoConApuesta { public boolean isApuestaRealizada(); }
interface JuegoConApuestaDinero extends JuegoConApuesta { public void cobrar(); }
interface JuegoConCarta { public void barajar(); }
interface JuegoConNaipes extends JuegoConCarta { public void repartir(); }
interface JuegoConTarjeta extends JuegoConCarta { public void leer(); }
interface JuegoConDado { public void lanzar(); }
interface JuegoConTablero { public void prepararTablero(); }
interface JuegoConLimiteTiempo { public void iniciarReloj(); }

abstract class Juego { 
	protected String nombre; // getters y setters
	protected int numeroJugadores; // getters y setters 
	public Juego() { this(null, 0); }
	public Juego(String nombre, int nj) {
		this.nombre = nombre;
		this.numeroJugadores = nj;
	}
	public abstract void iniciar();
	public abstract void finalizar();
}
abstract class JuegoMesa extends Juego {}
abstract class JuegoSalon extends Juego {
	protected boolean hablado;
	protected boolean conCapitan;
	public JuegoSalon(boolean h, boolean c) { 
		super(null, 0);
		hablado = h; conCapitan = c; 
	}
	public boolean isHablado() { return hablado; }
	public boolean isConCapitan() { return conCapitan; }
}

class Rol extends JuegoMesa implements JuegoConTablero, JuegoConTarjeta, JuegoConDado {
	public void iniciar() {} // Juego
	public void finalizar() {} // Juego
	public void prepararTablero() {} // JuegoConTablero
	public void lanzar() {} // JuegoConDao
	public void leer() {} // JuegoConTarjeta
	public void barajar() {} // JuegoConTarjeta -> JuegoConCarta
}
class Mus extends JuegoMesa implements JuegoConApuestaDinero, JuegoConNaipes {
	private boolean apuestaRealizada = false;
	public void iniciar() {} // Juego
	public void finalizar() {} // Juego
	public void cobrar() {} // JuegoConApuestaDinero
	public boolean isApuestaRealizada() { return apuestaRealizada; } // JuegoConApuestaDinero -> JuegoConApuesta
	public void repartir() {} // JuegoConNaipes
	public void barajar() {} // JuegoConNaipes -> JuegoConCarta

}
class Pictionary extends JuegoSalon implements JuegoConLimiteTiempo, JuegoConTarjeta, JuegoConTablero {
	// Este constructor sin parámetros debe llamar al constructor del padre con parámetros porque es la única forma de construirlo
	public Pictionary() { super(false, false); }
	public void iniciar() {} // Juego
	public void finalizar() {} // Juego
	public void leer() {} // JuegoConTarjeta
	public void barajar() {} // JuegoConTarjeta -> JuegoConCarta
	public void prepararTablero() {} // JuegoConTablero
	public void iniciarReloj() {} // JuegoConLimiteTiempo
}


