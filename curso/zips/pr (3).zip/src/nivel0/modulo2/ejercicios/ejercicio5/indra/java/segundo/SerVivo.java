package indra.java.segundo;

class SerVivo {
	protected String nombre;

	public SerVivo(String nombre) {
		this.nombre = nombre;
	}

        public void respirar() {
                System.out.println("Estoy respirando como un SerVivo");
        }

        public void comer() {
                System.out.println("Estoy comiendo como un SerVivo");
        }
}

