package indra.java.segundo;

class Animal extends SerVivo {
	public Animal() {
		super("animal");
	}
}
