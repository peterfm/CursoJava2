package indra.java.segundo;

class Persona extends SerVivo {
        private float peso;
        private float altura;

        public Persona(float p, float a) {
		super(null);
		super.nombre = "bla";
		this.nombre = "bla";
                peso = p;
                altura = a;
        }

        public void setPeso(float p) {
                peso = p;
        }

        public void setAltura(float a) {
                altura = a;
        }

        public float getPeso() {
                return peso;
        }

        public float getAltura() {
                return altura;
        }

        public float getDensidad() {
                return peso / altura;
        }

        public void respirar() {
                System.out.println("Estoy respirando como una Persona");
        }

        public void comer() {
                System.out.println("Estoy comiendo como una Persona");
        }

        public void comer(int cantidad) {
                System.out.println("Estoy comiendo como una Persona, cant = " + cantidad);
        }

        public void caminar() {
                System.out.println("Estoy caminando como una Persona");
        }

}


