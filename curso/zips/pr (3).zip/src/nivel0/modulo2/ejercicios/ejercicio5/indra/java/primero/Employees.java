package indra.java.primero;

import java.util.*;

public class Employees {
	public static void main(String args[]) {
		Manager m1 = new Manager();
		Employee e1 = new Manager();
		Director d1 = new Director();
		Manager m2 = new Director();
		Employee e2 = new Director();

		System.out.println("m1.getDetails() = " + m1.getDetails());
		System.out.println("e1.getDetails() = " + e1.getDetails());
		System.out.println("d1.getDetails() = " + d1.getDetails());
		System.out.println("m2.getDetails() = " + m2.getDetails());
		System.out.println("e2.getDetails() = " + e2.getDetails());

		if (d1 instanceof Employee)
			System.out.println("d1 es un Employee");
		if (d1 instanceof Manager)
			System.out.println("d1 es un Manager");
		if (d1 instanceof Director)
			System.out.println("d1 es un Director");
	
		// Cómo cambiamos el atributo carAllowance de e2?
		Director d2 = (Director) e2;
		d2.carAllowance = 200.0;

		((Director) e2).carAllowance = 200.0;

		Manager m3 = (Manager) e2;
		m3.department = "Compras";
	
		/***************************************/
		System.out.println("********************************");

		Employee[] es = new Employee[5];
		es[0] = new Employee();
	
		es[1] = new Manager();
		es[1].name = "María";
		es[1].salary = 10000;
		es[1].birthDate = new Date();
		((Manager) es[1]).department = "Ventas";
	
		Manager m4 = new Manager("Pedro", 3000, null);
		es[2] = m4;
		
		es[3] = new Director();
		Director d3 = (Director) es[3];
		d3.carAllowance = 3000;
		
		Manager m5 = new Manager();
		es[4] = m5;
		init(m5);

		Employee[] otrosEmployees = es;
		imprimir(otrosEmployees);
	}
	
	public static void imprimir(Employee[] es) {
		for (int i = 0; i < es.length; i++) {
			if (es[i] instanceof Director)
				System.out.println("La posición " + i + "es un Director");
			else if (es[i] instanceof Manager)
				System.out.println("La posición " + i + "es un Manager");
			else 
				System.out.println("La posición " + i + "es un Employee");
		}
	}

	public static void init(Employee e) {
		e.name = "Antonio";
		e.salary = 2000;
		
		if (e instanceof Manager) 
			((Manager) e).department = "Compras";
	}
}

class Employee {
	protected String name; // Puede acceder él, el paquete y sus hijos
	protected double salary;
	protected Date birthDate;

	public Employee() {
		this("Juan", 2000, new Date());
	}

	public Employee(String name, double salary, Date birthDate) {
		this.name = name;
		this.salary = salary;
		this.birthDate = birthDate;
	}

	public String getDetails() {
		return "[name = " + name + 
			", salary = " + salary + 
			", birthDate = " + birthDate + "]";
	}
}

class Manager extends Employee {
	public String department;

	public Manager(String name, double salary, String department) {
		super.name = name;
		this.salary = salary;

		this.department = department;
	}

	public Manager() {
		super("María", 1000, null);
		this.department = "Ventas";
	}


	public String getDetails() {
		return "[name = " + name + 
			", salary = " + salary + 
			", birthDate = " + birthDate + 
			", department = " + department + "]";
	}
}

class Director extends Manager {
	protected double carAllowance;

	public String getDetails() {
		return "[name = " + name + 
			", salary = " + salary + 
			", birthDate = " + birthDate + 
			", department = " + department + 
			", carAllowance = " + carAllowance + "]";
	}

}



