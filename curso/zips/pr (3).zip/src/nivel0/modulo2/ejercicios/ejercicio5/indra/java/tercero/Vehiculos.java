package indra.java.tercero;

public class Vehiculos {
	public static void main(String args[]) {
		Vehiculo v = new Vehiculo();
		Auto a = new Auto();
		Camioneta  c = new Camioneta();

		v.caracteristicas();
		System.out.println();
		a.caracteristicas();
		System.out.println();
		c.caracteristicas();

		Vehiculo[] vhs = new Vehiculo[5];
		vhs[0] = new Auto("Juan", true);
		vhs[1] = new Auto("María", false);
		vhs[2] = new Camioneta("Pedro", (float)20.0, 30.0f);
		vhs[3] = new Camioneta("Silvia", 50f, 20f);
		vhs[4] = new Vehiculo("Ana", 0, 2);
		
		System.out.println("*****************");
		for (Vehiculo v1 : vhs) {
			System.out.println(v1.getClass());
			v1.caracteristicas();
			System.out.println();
		}
	}
}

class Vehiculo {
	protected String dueno;
	protected int puertas;
	protected int ruedas;

	public Vehiculo() {
		this(0, 4);
		this.dueno = "Desconocido";
	}

	public Vehiculo(String dueno, int puertas, int ruedas) {
		this.dueno = dueno;
		this.puertas = puertas;
		this.ruedas = ruedas;
	}
	
	public Vehiculo(int puertas, int ruedas) { 
		this(null, puertas, ruedas);
	}

	protected void finalize() throws Throwable {
		System.out.println("Finalizado el vehículo");
	}

	public void caracteristicas() {
		System.out.println("dueno = " + dueno);
		System.out.println("puertas = " + puertas);
		System.out.println("ruedas = " + ruedas);
	}
}

class Auto extends Vehiculo {
	private boolean descapotable;

	public Auto() {
		super();	
		this.descapotable = true;
	}

	public Auto(boolean descapotable) {
		this(null, descapotable);
	}

	public Auto(String dueno, boolean descapotable) {
		super(dueno, 3, 4);
		this.descapotable = descapotable;
	}

	public void caracteristicas() {
		super.caracteristicas();
		System.out.println("descapotable = " + descapotable);
	}

	public void subir() {
		System.out.println("Subiendo");
	}

	public void bajar() {
		System.out.println("Bajando");
	}

}

class Camioneta extends Vehiculo {
	private float tara;
	private float carga;

	public Camioneta() {
		this(null, 0, 0);
	}

	public Camioneta(float tara, float carga) {
		this(null, tara, carga);
	}

	public Camioneta(String dueno, float tara, float carga) {
		super(dueno, 5, 4);
		this.tara = tara;
		this.carga = carga;	
	}

	public void caracteristicas() {
		super.caracteristicas();
		System.out.println("tara = " + tara);
		System.out.println("carga = " + carga);

	}

	public void cargar(float kilos) {
		System.out.println("Cargando " + kilos + " kilos");
	}

}
