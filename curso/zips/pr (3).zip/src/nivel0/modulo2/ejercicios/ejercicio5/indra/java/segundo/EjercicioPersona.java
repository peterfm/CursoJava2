package indra.java.segundo;

public class EjercicioPersona {
	public static void main(String args[]) {
		SerVivo sv = new Persona(80f, 180f);
		sv.comer();
		sv.respirar();

		if (sv instanceof Persona) {
			((Persona) sv).caminar();
			Persona p = (Persona) sv;
			p.comer(20);
		}
		
	}
}

