import java.util.Date;

public class ClasesBasico {
	public static void main(String args[]) {
		Employee e = new Employee();
		e.name = "Juan";
		e.salary = 1000;
		e.birthDate = new Date();

		System.out.println(e);
		System.out.println(e.getDetails());

		Manager m = new Manager();
		m.name = "Pedro";
		m.salary = 2000;
		m.birthDate = new Date();
		m.department = "Ventas";
		
		System.out.println(m.getDetails());
		System.out.println("=>" + m);

		/*** Polimorfismo de clases ***/
		e = new Manager();
		e.name = "Pedro";
		e.salary = 2000;
		e.birthDate = new Date();
		//e.department = "Ventas";

		System.out.println(e.getDetails());

		// Cómo obtengo el departamento?? de la instancia en "e"
		Manager m1 = (Manager) e;
		System.out.println(m1.sayHi());

		Employee e1 = m1; 
		
	}
}

class Employee {
	public String name;
	public double salary;
	public Date birthDate;

	public String getDetails() {
		return "[name = " + name + 
			", salary = " + salary +
			", birthDate = " + birthDate + "]";
	}

	public String getDetails(String a) {
		return "[name = " + name + 
			", salary = " + salary +
			", birthDate = " + birthDate + "]";
	}

	public String toString() {
		return this.getDetails("");
	}

}

class Manager extends Employee {
	public String department;

	public String getDetails() {
		return super.getDetails()  +
			", department = " + department + "]";

	}

	public String sayHi() {
		return "Hi!";
	}
}

