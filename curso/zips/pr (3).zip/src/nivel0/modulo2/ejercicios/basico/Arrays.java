public class Arrays {	
	public static void main(String args[]) {
		String nombres[] = {"Juan", "Pedro", "María"};

		for (int i = 0; i < nombres.length; i++) {
			System.out.println(nombres[i]);
		}

		System.out.println();
		for (String n : nombres) {
			System.out.println(n);
		}

		int[][] numeros = new int[4][];
		inicializar(numeros);
	
		imprimir(numeros);
	}

	/**
	 * El paso de la variable numeros es por referencia!!!
	 */ 
	public static void inicializar(int[][] numeros) {
		int y = 1;
		for (int i = 0; i < numeros.length; i++) {
			numeros[i] = new int[y++];

			for (int j = 0; j < numeros[i].length; j++) {
				numeros[i][j] = i * j;
			}
		}
	}

	/**
	 * El paso de la variable numeros es por referencia!!!
	 */
	public static void imprimir(int[][] numeros) {
		for (int[] fila : numeros) {
			for (int n : fila) {
				System.out.print(n + ", ");
			}
			System.out.print("\n");
		}
	
	}
}
