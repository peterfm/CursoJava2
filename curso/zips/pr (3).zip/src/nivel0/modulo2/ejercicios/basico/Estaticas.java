public class Estaticas {
	public int contadorInstancia;
	public static int contador;

	public static void main(String args[]) {
		Estaticas e1 = new Estaticas();
		e1.contadorInstancia++;
		e1.contador++;
		System.out.println(e1.contadorInstancia); // => 1
		System.out.println(e1.contador); // => 1

		Estaticas e2 = new Estaticas();
		e2.contadorInstancia++;
		e2.contador++;
		System.out.println(e2.contadorInstancia); // => 1
		System.out.println(e2.contador); // => 2

		Estaticas.contador++;
		System.out.println(Estaticas.contador); // => 3

		OtraEstatica.caminar();
		e2.respirar();
	}

	public void respirar() {
		OtraEstatica.caminar();
	}
}

class OtraEstatica {
	public static void caminar() {
		System.out.println("Estoy caminando... " + Estaticas.contador);

	}


}

