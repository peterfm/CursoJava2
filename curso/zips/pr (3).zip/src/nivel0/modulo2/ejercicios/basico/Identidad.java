public class Identidad {
	public static void main(String args[]) {
		Proyector p1 = new Proyector(1, "LED");
		Proyector p2 = new Proyector(1, "LED");
		System.out.println("\nnew Proyector(\"LED\") con new Proyector(\"LED\")");
		comparar(p1, p2); // => Son diferentes

		String a = "Hola";
		String b = "Hola";
		System.out.println("\n\"Hola\" con \"Hola\"");
		comparar(a, b); // => Son idénticos

		String c = new String("Hola");
		String d = new String("Hola");
		System.out.println("\nnew String(\"Hola\") con new String(\"Hola\")");
		comparar(c, d); // => Son diferentes
	}

	public static void comparar(Object a, Object b) {
		if (a == b)
			System.out.println("Son idénticos");
		else 
			System.out.println("No son idénticos");

		if (a.equals(b))
			System.out.println("Son iguales");
		else 
			System.out.println("Son diferentes");


	}
}

class Proyector {
	public String tipo;
	public int id;

	public Proyector(int id, String tipo) { this.id = id; this.tipo = tipo; }

	public boolean equals(Object obj) {
		if (obj instanceof Proyector) {
			Proyector p = (Proyector) obj;
			return (p.id == this.id && p.tipo.equals(this.tipo));
		} else {
			return false;
		}
	}

	public int hashCode() {
		return this.id ^ this.tipo.hashCode();
	}

}
