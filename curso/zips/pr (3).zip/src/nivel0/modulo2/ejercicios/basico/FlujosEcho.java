import java.io.*;

public class FlujosEcho {
	public static void main(String args[]) throws Exception {
		InputStream is = System.in;
		InputStreamReader isr = new InputStreamReader(is);
		BufferedReader br = new BufferedReader(isr);

		while(true) {
			String linea = br.readLine();
			System.out.println(linea);	
		}
	}
}
