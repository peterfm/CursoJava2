public class OperacionesMatematicas {
	public static void main(String args[]) {
		int a = 1;
		int b = 2;
		float f = 2f;
		float c = a / b;
		float d = (float)a / b;
		float e = a / f;
		System.out.println(c); // => 0.0
		System.out.println(d); // => 0.5
		System.out.println(e); // => 0.5
		
	}
}
