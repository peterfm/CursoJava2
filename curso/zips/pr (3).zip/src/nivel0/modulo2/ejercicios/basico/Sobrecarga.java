public class Sobrecarga {
	public static void main(String args[]) {
		Poli p = new Poli();
		int b = p.hola("a");
		String a = p.hola("a");	
	}

	public int hola(String a) {
		System.out.println("Hola void");
		return 0;
	}
	
	public String hola(String bb) {
		System.out.println("Hola String");
		return null;
	}
}
