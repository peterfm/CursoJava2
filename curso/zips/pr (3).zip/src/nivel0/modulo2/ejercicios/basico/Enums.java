public class Enums {
	public static void main(String args[]) {
		System.out.println(new Carta(1, TipoCarta.OROS));
		System.out.println(new Carta(2, TipoCarta.BASTOS));

		int tipo = (int) Math.round((Math.random() * 4));
		new Carta(1, TipoCarta.getTipoCarta(tipo));

		for (TipoCarta tp : TipoCarta.values()) {
			System.out.println(tp);
		}
		
	}
}	

enum TipoCarta {
	OROS(1, "Gold"),
	COPAS(2, "Cups"),
	ESPADAS(3, "Spades"),
	BASTOS(4, "Clubs");

	private int idx;
	private String nombre;
	
	private TipoCarta(int idx, String nombre) {
		this.idx = idx;
		this.nombre = nombre;
	}

	public int getIdx() { return idx; }
	public String getNombre() { return nombre; }

	public static TipoCarta getTipoCarta(int tipo) {
		TipoCarta tipoCarta = null;

		switch (tipo) {
			case 0:
				tipoCarta = TipoCarta.OROS;
				break;
			case 1: 
				tipoCarta = TipoCarta.COPAS;
				break;
			case 2:
				tipoCarta = TipoCarta.ESPADAS;
				break;
			default:
				tipoCarta = TipoCarta.BASTOS;
				
		}

		return tipoCarta;
	}

}

class Carta {
	public int numero;
	public TipoCarta tipo;

	public Carta(int numero, TipoCarta tipo) {
		this.numero = numero;
		this.tipo = tipo;
	}

	public String toString() {
		return "[numero = " + numero + 
			", tipo = " + tipo + " " + 
			tipo.getNombre() + " " +
			tipo.ordinal() + " " +
			tipo.name() + " " +
			tipo.getIdx() + "]";
	}
	
}
