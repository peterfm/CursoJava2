import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class ColeccionesGenerico {
	public static void main(String args[])  {
		List l1 = new ArrayList();
		l1.add(new A(1));
		l1.add(new A(2));
		l1.add(new A(3));
		
		for (Object o : l1) {
			if (o instanceof A) {
				A a = (A) o;
				System.out.println(a.a);
			}
		}

		List<A> l2 = new ArrayList<A>();
		l2.add(new A(1));
		l2.add(new A(2));
		l2.add(new A(3));
		l2.add(new B(4, 1));

		Collections.sort(l2, new Comparator<A>() {
			public int compare(A a, A b) {	
				if (a.a > b.a)
					return 1;
				else if (a.a < b.a)
					return -1;
				else
					return 0;
			}
		});
		
		System.out.println("***************");
		for (A a : l2) {
			String mensaje = Integer.toString(a.a);

			if (a instanceof B) 
				mensaje += ((B) a).b;

			System.out.println(mensaje); 

		}

		/*************** Mapa ****************/
		Map<Integer, String> empleados = new Hashtable<Integer, String>();
		empleados.put(1, "Juan");
		empleados.put(33, "Pedro");
		
		for (Integer id : empleados.keySet()) {
			System.out.println(empleados.get(id)); // Retorna un String!!!
		}
	


	}
}

class A {
	public int a;
	public A(int a) { this.a = a; }
	public String toString() { return Integer.toString(a); }

	public boolean equals(Object obj) {
		if (obj instanceof A) 
			return (((A) obj).a == a);
		else
			return false;
	}

	public int hashCode() {
		return a;
	}
}

class B extends A { 
	public int b;
	public B(int a, int b) { 
		super(a); 
		this.b = b;
	} 
}
