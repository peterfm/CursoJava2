public class Envoltorio {
	public static void main(String args[]) {
		int a = 2;
		int b = 2;
		System.out.println("a + b = " + (a + b));

		Integer c = 1;
		Integer d = 2;
		System.out.println("c + d = " + (c + d)); // Autounboxing!
		System.out.println("c + d = " + (c.intValue() + d.intValue()));

		c = a; // Autoboxing
		d = new Integer(b);

		if (c.equals(d)) 
			System.out.println("Son iguales");
		else 
			System.out.println("Son diferentes");
	
		String numero = "1";
		c = Integer.parseInt(numero);

		String otro = Integer.toString(a);

		long mushio = Long.MAX_VALUE;
		a = (int) mushio;

		System.out.println(Long.toString(mushio));
		System.out.println(a);

	}
}
