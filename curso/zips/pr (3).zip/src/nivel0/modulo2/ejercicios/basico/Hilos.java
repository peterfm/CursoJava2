public class Hilos {
	public static void main(String args[]) {
		A a = new A();

		new Thread(a).start(); // Desprende el hilo ejecutando el método run()
		new Thread(a).start(); // Desprende el hilo ejecutando el método run()
		new Thread(a).start(); // Desprende el hilo ejecutando el método run()
		new Thread(a).start(); // Desprende el hilo ejecutando el método run()
	}
}

class A implements Runnable {
	public int a = 0;

	synchronized void imprimir(String mensaje) {
		//...
	}

	public void run() {
		while (true) {
			synchronized (this) {
				a++;

				System.out.println("Hilo: " + 
					"[id = " + Thread.currentThread().getId() +
					", nombre = " + Thread.currentThread().getName() + 
					", a = " + a + "]");
			}

			try { Thread.sleep(100); } catch(Exception e) {}
		}
	}
}
