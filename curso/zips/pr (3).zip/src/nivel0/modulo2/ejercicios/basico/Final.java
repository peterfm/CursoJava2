public class Final {
	public static void main(String args[]) {

	}
}

final class A {
	public final C c = new C();

	public A() {
		c.contador = 3;
//		c.c = 3;
	}
}

//class B extends A {}

class C {
	public final int c = 33;
	public int contador;

	public final void caminar () { }
	public void respirar () {}
}

class D extends C{
	public final int d;

	public D() {
		d = 44;
//		d = 33;
	}

//	public void caminar () {}
	public void respirar () {}
}
