import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class Colecciones {
	public static void main(String args[])  {
		/***************** List ******************/
		List l = new ArrayList();
		l.add("uno");
		l.add(2);
		l.add("3");
		l.add(2);
		l.add("2");
		l.add(new A(3));
		
		System.out.println(l);

		System.out.println("***************");
		for (int i = 0; i < l.size(); i++) {
			System.out.println(l.get(i));
		}

		System.out.println("***************");
		for (Object o : l) {
			System.out.println(o);
		}

		System.out.println("***************");
		Iterator iter = l.iterator();
		while (iter.hasNext()) {
			Object o = iter.next();
			System.out.println(o);
		}
		
		/***************** Set ******************/

		Set s = getSet();
		s.add("uno");
		s.add(2);
		s.add("3");
		s.add(2); // => no lo añade
		s.add("2");
		s.add(new Integer(2)); // => no lo añade
		s.add(new A(3));
		s.add(new A(3)); // => para que no lo añada debemos sobreescribir los métodos equals y hashCode!
		
		System.out.println("******** Set *********");
		System.out.println(s); // => ["uno", 2, "3", "2", 3]

		System.out.println("***************");
		Object[] sobj = s.toArray();
		for (int i = 0; i < sobj.length; i++) {
			System.out.println(sobj[i]);
		}

		System.out.println("***************");
		for (Object o : s) {
			System.out.println(o);
		}

		System.out.println("***************");
		iter = s.iterator();
		while (iter.hasNext()) {
			Object o = iter.next();
			System.out.println(o);
		}
	

	}
	
	public static Set getSet() {
		return new LinkedHashSet();
	}
}

class A {
	public int a;
	public A(int a) { this.a = a; }
	public String toString() { return Integer.toString(a); }

	public boolean equals(Object obj) {
		if (obj instanceof A) 
			return (((A) obj).a == a);
		else
			return false;
	}

	public int hashCode() {
		return a;
	}
}
