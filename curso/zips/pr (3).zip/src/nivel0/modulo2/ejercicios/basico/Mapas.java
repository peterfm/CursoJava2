import java.util.*;

public class Mapas {
	public static void main(String args[]) {
		Map m = new Hashtable();
		m.put("Rodolfo", "Campos");
		m.put("María", 20);
		m.put("Juan", new Date());
		m.put(1, new A(1));

		System.out.println(m.get(1)); // => 1
		System.out.println(m.values());
		for (Object obj : m.values()) {
			System.out.println(obj);
		}

		System.out.println("***********");
		for (Object key : m.keySet()) {
			System.out.println(m.get(key));
		}
	}
}

class A {
	public int a;
	public A(int a) { this.a = a; }
	public String toString() { return Integer.toString(a); }
}
