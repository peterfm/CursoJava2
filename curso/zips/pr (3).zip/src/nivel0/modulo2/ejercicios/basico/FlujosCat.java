/*
$ cat <<LISTO >/tmp/salida
> hola
> uno
> todo bien
> LISTO
*/
import java.io.*;
import java.util.*;

public class FlujosCat {
	public static void main(String args[]) throws Exception {
		if (args == null || args.length != 2)  {
			System.err.println("Uso: java FlujosEcho PALABRA_FIN NOMBRE_ARCHIVO");
			System.err.println("\tPALABRA_FIN: Palabra que indica el fin de la ejecución");
			System.err.println("\tNOMBRE_ARCHIVO: Nombre del archivo de destino");

			System.exit(-1);
		}
		// Para escribir	
		FileOutputStream fos = new FileOutputStream(args[1]);
		OutputStreamWriter osw = new OutputStreamWriter(fos);
		PrintWriter pw = new PrintWriter(osw);

		// Para leer
		Scanner scanner = new Scanner(System.in);
		String linea = scanner.nextLine();		

		while(linea != null && !linea.equals(args[0])) { // Para cuando linea == PALABRA_FIN
			pw.println(linea);	
			linea = scanner.nextLine();
		}
		
		pw.flush(); // Efectivamente escribe en el archivo!
		fos.close();
		scanner.close();
	}
}
