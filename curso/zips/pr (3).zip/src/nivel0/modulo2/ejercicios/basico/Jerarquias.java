public class Jerarquias {
	public static void main(String args[]) {
		Motion m1 = new SeaPlane();
		Motion m2 = new Helicopter();

		Sailer s1 = (Sailer)m1;

		System.out.println(m1);
		System.out.println(m2);
		System.out.println(s1);

		((Energy) m2).ki();

		if (m1 instanceof Motion)
			System.out.println("m1 es instancia de Motion");
		if (m1 instanceof Energy)
			System.out.println("m1 es instancia de Energy");
		if (m1 instanceof Flyer)
			System.out.println("m1 es instancia de Flyer");
		if (m1 instanceof Sailer)
			System.out.println("m1 es instancia de Sailer");
		if (m1 instanceof Plane)
			System.out.println("m1 es instancia de Plane");
		if (m1 instanceof Vehicle)
			System.out.println("m1 es instancia de Vehicle");
		if (m1 instanceof Airplane)
			System.out.println("m1 es instancia de Airplane");

	}
}

interface Energy {
	public double ki();
}

interface Motion {
	public double velocity();
}

interface Flyer extends Motion, Energy {
	public void takeOff();
	public void land();
	public void fly();
}

interface Sailer {
	public void dock();
	public void cruise();
}

interface Plane {
	public void up();
	public void down();
}

abstract class Vehicle {
	public abstract double calcFuelEfficiency();
	public abstract double calcTripDistance();

	public String toString() {
		return "Soy un vehicle: " + this.getClass().getSimpleName();
	}
}

class Truck extends Vehicle {
	private double maxLoad;
	public Truck(double maxLoad) { this.maxLoad = maxLoad; }
	public double calcFuelEfficiency() { return 0.0; }
	public double calcTripDistance() { return 0.0; }
}

class RiverBarge extends Vehicle implements Sailer {
	private double maxLoad;
	public RiverBarge(double maxLoad) { this.maxLoad = maxLoad; }
	public double calcFuelEfficiency() { return 0.0; }
	public double calcTripDistance() { return 0.0; }
	public void dock() {}
 	public void cruise() {}
}

class Airplane extends Vehicle implements Flyer, Plane {
	/** Métodos de Vehicle **/
	public double calcFuelEfficiency() { return 0.0; }
	public double calcTripDistance() { return 0.0; }
	/** Métodos de Flyer **/
	public void takeOff() {}
	public void land() {}
	public void fly() {}
	/** Métodos de Motion **/
	public double velocity() { return 0.0; }
	/** Métodos de Energy **/
	public double ki() { return 0.0; }
	/** Métodos de Plane **/
	public void up() {}
	public void down() {}
}

class SeaPlane extends Airplane implements Sailer {
	public void dock() {}
	public void cruise() {}
}

class Helicopter extends Airplane {}





