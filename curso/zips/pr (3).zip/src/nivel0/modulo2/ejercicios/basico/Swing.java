import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Swing {
	public static void main(String args[]) {	
		new Principal().launchFrame();
	}
}

class Principal {
	JFrame f;
	JButton b, b1;
	
	public Principal() {
		f = new JFrame("Ventana");
		b = new JButton("Clic aquí");
		b1 = new JButton("Clic allá");
	}

	public void launchFrame() {
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				System.out.print("Uno");
			}
		});
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				System.out.print("Dos");
			}
		});

		b.addKeyListener(new KeyListener() {
			public void keyTyped(KeyEvent ke) { System.out.println("a"); }
			public void keyReleased(KeyEvent ke) { System.out.println("a"); }
			public void keyPressed(KeyEvent ke) {
				System.out.println("Presionó una tecla!!!");
			}
		});

		f.add(b, BorderLayout.CENTER);
		f.add(b1, BorderLayout.EAST);
		f.pack();
		f.setVisible(true);
	}
}
