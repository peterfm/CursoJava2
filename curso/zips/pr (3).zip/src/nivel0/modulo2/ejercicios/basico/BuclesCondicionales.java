public class BuclesCondicionales {
	public static final int MES_ENERO = 1;
	public static final int MES_FEBRERO = 2;
	public static final int MES_ABRIL = 4;

	public static void main(String args[]) {
		int edad = 9;
		int mes = MES_FEBRERO;

		/****** Condicionales *****/
		if (edad >= 18) 
			System.out.println("Puedes manejar");
		else if (edad >=16) 
			System.out.println("Puedes manejar ciertas motos");
		else 
			System.out.println("Debes esperar");
		
		switch (mes) {
			case MES_ENERO:
				System.out.println("Tiene 31 días");
			case MES_FEBRERO:
				System.out.println("Tiene menos de 30 días");
				break;
			case MES_ABRIL:
				System.out.println("Tiene 30 días");
			default: 
				System.out.println("No conozco ese mes del año");
		}
		
		/********* Bucles **********/
		for (int i = 0; i < 10 ; i++) {
			System.out.println("i = " + i);
		}

		int i;
		for (i = 0; i < 10 ; i++) {
			System.out.println("i = " + i);
		}

		i = 0;
		for (; i < 10 ; i++) {
			System.out.println("i = " + i);
		}
		
		i = 0;
		for (; i < 10 ; i++) {
			System.out.println("i = " + i);
		}
 
		i = 0;
		int a = 2;
		for (a = 3; true; ) {
			if (i == 10)
				break;

			if (i > 2 && i < 6) {
				i++;
				continue;
			}

			System.out.println("i = " + i++);
		}

		System.out.println("a = " + a);

		System.out.println("***************************");
		i = 0;
		while (i < 10) {
			System.out.println("i = " + i++);
		}

		i = 0;
		while (true) {
			if (i == 10) 
				break;

			System.out.println("i = " + i++);
		}
		
		i = 0;
		boolean siempre = (1 == 1) && (2 == 2) && true;
		while (siempre) {
			if (i == 10) 
				break;

			System.out.println("i = " + i++);
		}
	
	}
}
