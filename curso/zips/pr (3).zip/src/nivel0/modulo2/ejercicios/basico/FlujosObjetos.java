import java.io.*;

public class FlujosObjetos {
	public static void main(String args[]) throws Exception {
		if (args == null || args.length != 1) {
			System.out.println("Debe especificar un nombre de archivo");
			System.exit(-1);
		}

		A a = new A(1);

		// Serializando "a"
		FileOutputStream fos = new FileOutputStream(args[0]);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(a);
		fos.close();

		// Deserializando "a"
		FileInputStream fis = new FileInputStream(args[0]);
		ObjectInputStream ois = new ObjectInputStream(fis);
		a = (A) ois.readObject();
		fis.close();


		System.out.println(a);

	}
}

class A implements Serializable {
	public int a;
	public A(int a) { this.a = a; }
	public String toString() { return "[a = " + a + "]"; }
}

class TemporalOutputStream extends OutputStream {
	public String valor;
	
}
