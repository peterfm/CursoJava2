public class Num {
	public static void main(String args[]) {
		int a = 2;
		int b = a;

		b = b + 1;
		System.out.println(a); // => 2
		System.out.println(b); // => 3

		/***********************************/

		A ref1 = new A(2);
		A ref2 = ref1;
		A ref3 = null;

		System.out.println(ref3.a); // => ?
		ref2.a = ref2.a + 1;
		System.out.println(ref1.a); // => 2
		System.out.println(ref2.a); // => 3
		
	}
}

class A {
	public int a;

	public A(int ab) { a = ab; }
}
