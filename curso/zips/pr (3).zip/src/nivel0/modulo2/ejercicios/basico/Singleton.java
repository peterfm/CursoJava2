public class EjemploSingleton {
	public static void main(String args[]) {
		Singleton.getInstance().contador++;
		Singleton.getInstance().contador++;
		System.out.println(Singleton.getInstance().contador); // => ?
		
		Singleton s1 = new Singleton();

	}
}

class Singleton {
	private static final Singleton INSTANCE = new Singleton();
	public int contador;

	private Singleton() {

	}

	public static Singleton getInstance() {
		return INSTANCE;
	}
}
