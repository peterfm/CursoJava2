public class A {
	public int a = 2;

	public A() {
		a = 44;
	}

	public static void main(String args[]) {
		A ref = new A();
		int tmp = ref.a;
		System.out.println(tmp);
	}
}
