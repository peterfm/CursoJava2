/*
 * 1. La clase debe tener el mismo nombre del archivo
 * 2. Las clases se llaman CamelCase siempre comenzando en mayúscula
 * 3. Un archivo puede tener varias clases, pero sólo una de ellas pública
 */

public class TestGreeting {
	public static void main(String args[]) {
		Greeting g = new Greeting();
		g.hi();
	}
}

class Greeting {
	public void hi() {
		System.out.println("Hi!");
	}
}
