public class Operadores {
	public static void main(String args[]) {
		int a = 1;
		int b = 2;

		int c = a * b / a++;

		System.out.println("c = " + c); // => 2 (Primero incrementa a en 1 y luego resuelve la multiplicación)

		int d = a++;
		int e = ++a;

		System.out.println("d = " + d); // => 2
		System.out.println("e = " + e); // => 4
		
		a -= 2;
		a = a - 2;
		System.out.println("a = " + a); // => 0
	}
}
