public class Fecha {
	private int dia;
	private int mes;
	private int anio;

	public Fecha(int d, int m, int a) {
		dia = d;
		mes = m;
		anio = a;
	}


	public void setDia(int d) { 
		if (d > 0 && d <= 31)
			dia = d; 
	}
	public void setMes(int m) { 
		if (m > 0 && m <= 12) 
			mes = m; 
	}
	public void setAnio(int a) { 
		if (a != 0)
			anio = a; 
	}

	public int getDia() { return dia; }
	public int getMes() { return mes; }
	public int getAnio() { return anio; }

	public void copiarDia(Fecha f) {
		cambiarDia(this, f);
	}

	public void cambiarDia(Fecha f1, Fecha f2) {
		f2.setDia(f1.getDia());

	}

	public static void main(String args[]) {
		Fecha f1 = new Fecha(1, 3, 2014); 
//		f1.setDia(1);
//		f1.setMes(3);
//		f1.setAnio(2014);

		Fecha f2 = new Fecha(2, 2, 2);
		f2.setDia(-4);
		f2.setMes(45);
		f2.setAnio(0);

		f1.copiarDia(f2);  // Asigna a f2 el día de f1

		System.out.println("Día: " + f1.getDia()); // => 2
		System.out.println("Mes: " + f1.getMes());
		System.out.println("Anio: " + f1.getAnio());

		System.out.println("Día: " + f2.getDia());
		System.out.println("Mes: " + f2.getMes());
		System.out.println("Anio: " + f2.getAnio());
	}
}


