import java.util.*;
import java.text.*;

public class Fechas {
	public static void main(String args[]) throws Exception {
		Date ahora = new Date();
		System.out.println(ahora);

		/********* Definiendo una fecha específica **********/
		// Con Calendar
		Calendar cal1 = Calendar.getInstance();
//		cal1.set(1979, 0, 22, 16, 30, 0);
		cal1.set(Calendar.DAY_OF_MONTH, 22); // Comienza en 0
		cal1.set(Calendar.MONTH, 0); // Comienza en 0
		cal1.set(Calendar.YEAR, 1979); // Se comporta normal
		cal1.set(Calendar.HOUR_OF_DAY, 16); // Se comporta normal
		cal1.set(Calendar.MINUTE, 30); // Se comporta normal

		Date f1 = cal1.getTime();
		System.out.println(f1);	

		// Con SimpleDateFormat
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date f2 = sdf.parse("1979-01-23 16:30");
		System.out.println(f2);
		
		/********* Extrayendo un dato específico **********/
		Date f3 = new Date();
		Calendar cal2 = Calendar.getInstance(); 
		cal2.setTime(f3);
//		cal2.setTime(f3.getTime()); // Unix Timestamp
		System.out.println(f3);
		System.out.println("minutos: " + cal2.get(Calendar.MINUTE));


	}
}
