import java.util.*;
import java.io.*;

public class FlujosLinea {
	public static void main(String args[]) throws Exception {
		if (args != null && args.length == 1) {
			leerLineas(args[0]);
			System.out.println("*****************");
			leerPalabras(args[0]);
			System.out.println("*****************");
			leerPalabrasTokenizer(args[0]);
		}
	}

	public static void leerLineas(String archivo) throws Exception {
		// 1.- Abriendo archivo para lectura
		InputStream fis = new FileInputStream(archivo);
		// 2.- Convirtiendo el flujo de bytes a un flujo de caracteres
		InputStreamReader isr = new InputStreamReader(fis); // Conversor!!
		// 3.- Convirtiendo el flujo de caracteres a un buffer de caracteres
		BufferedReader br = new BufferedReader(isr);
			
		String linea = br.readLine();
		while (linea != null) {
			System.out.println(linea);
			linea = br.readLine();
		}		

		fis.close();
	}

	public static void leerPalabras(String archivo) throws Exception {
      // 1.- Abriendo archivo para lectura
      InputStream fis = new FileInputStream(archivo);
      // 2.- Convirtiendo el flujo de bytes a un flujo de caracteres
      InputStreamReader isr = new InputStreamReader(fis); // Conversor!!
      // 3.- Convirtiendo el flujo de caracteres a un buffer de caracteres
      BufferedReader br = new BufferedReader(isr);
         
      String linea = br.readLine();
      while (linea != null) {
			String[] palabras = linea.split(" ");
			for (String palabra : palabras) {
				System.out.println(palabra);
			}
         linea = br.readLine();
      }     

      fis.close();

	}

	public static void leerPalabrasTokenizer(String archivo) throws Exception {
      // 1.- Abriendo archivo para lectura
      InputStream fis = new FileInputStream(archivo);
      // 2.- Convirtiendo el flujo de bytes a un flujo de caracteres
      InputStreamReader isr = new InputStreamReader(fis); // Conversor!!
      // 3.- Convirtiendo el flujo de caracteres a un buffer de caracteres
      BufferedReader br = new BufferedReader(isr);
         
      String linea = br.readLine();
      while (linea != null) {
			StringTokenizer st = new StringTokenizer(linea, " ");
			while (st.hasMoreTokens()) {
				System.out.println(st.nextElement());
			}
         linea = br.readLine();
      }     

      fis.close();

	}

}
