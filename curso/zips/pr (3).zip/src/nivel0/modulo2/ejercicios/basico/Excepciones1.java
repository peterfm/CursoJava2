public class Excepciones1 {
	public static void main(String args[]) {
		for (String a : args) {
			if (UtilEnteros.validar(a)) 
				System.out.println(a + " es un número");
			else 
				System.out.println(a + " no es un número");
		}
		System.out.println("**************");
		for (String a : args) {
			try {
				int i = UtilEnteros.convertir1(a);
				System.out.println(a + " es un número");
			} catch (NumberFormatException nfe) {
				System.out.println(a + " no es un número");
			}
		}
		System.out.println("**************");
		for (String a : args) {
			try {
				int i = UtilEnteros.convertir2(a);
				System.out.println(a + " es un número");
			} catch (NumeroInvalidoException e) {
				System.out.println(e.getValor() + " no es un número");
			}
		}
	}
}
// Excepción no verificada (unchecked)
class NumeroInvalidoRuntimeException extends RuntimeException {}
// Excepción verificada (checked)
class NumeroInvalidoException extends Exception {
	private String valor; 
	public NumeroInvalidoException(String mensaje, String valor) { 
		super(mensaje); 
		this.valor = valor;
	}
	public String getValor() { return valor; }
}

class UtilEnteros {
	public static int convertir1(String valor) throws NumberFormatException {
			return Integer.parseInt(valor);
	}

	public static int convertir2(String valor) throws NumeroInvalidoException {
		try {			
			return Integer.parseInt(valor);
		} catch (NumberFormatException nfe) {
			throw new NumeroInvalidoException("El valor = " + valor + "no es numérico", valor);
		}
	}

	public static boolean validar(String valor) {
		boolean valido = false;
		try {
			Integer.parseInt(valor);
			valido = true;
		} catch (NumberFormatException nfe){} 

		return valido;
	}

}
