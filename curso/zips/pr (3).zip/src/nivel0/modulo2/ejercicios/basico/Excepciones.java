public class Excepciones {
	public static void main(String args[]) {
		UtilEnteros util = new UtilEnteros();

		for (String a : args) {
			try {
				Integer.parseInt(a);
				System.out.println(a + " es un número");
			} catch(NumberFormatException nfe) {
				System.err.println(a + " no es un número: " + nfe.getMessage());
				nfe.printStackTrace();
			} catch (Exception e ) {
				e.printStackTrace();
			} finally {
				System.out.println("Finalizando!!");
			}
		}

		System.out.println("****************");
		for (String a : args) {
			util.validar(a);
		}
	}
}

class UtilEnteros {
	A a;

	public UtilEnteros() { this.a = new A(); }

	public void validar(String valor) {
		uno(valor);		
		System.out.println("validar"); // => si se imprime
	}

	public void uno(String valor) {
		try {	
			dos(valor);
			System.out.println("uno (dentro del catch)");  // => no se imprime
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("uno (fuera del catch)"); // => si se imprime
	}
	public void dos(String valor) {
		a.uno(valor);
		System.out.println("dos"); // => no se imprime
	}
}

class A {
	public void uno(String valor) {
			Integer.parseInt(valor);
			System.out.println("a.uno"); // => no se imprime
	
	}
}

