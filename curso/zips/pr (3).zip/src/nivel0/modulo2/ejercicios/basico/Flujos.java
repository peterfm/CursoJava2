import java.io.*;

public class Flujos {
	public static void main(String args[]) {
		if (args != null && args.length == 1) {
			// 1.- Abriendo archivo para lectura
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(args[0]);

				int b = fis.read();
				while (b != -1) {
					System.out.print((char) b);
					b = fis.read();
				}
			} catch (FileNotFoundException fnfe) {
				System.err.println("Error al abrir el archivo: " + fnfe.getMessage());
			} catch (IOException ioe) {
				System.err.println("Error al leer el archivo: " + ioe.getMessage());
			} catch (Exception e) {
				System.err.println("Error absolutamente inesperado: " + e.getMessage()); 
			} finally {
				if (fis != null) {
					try {
						fis.close();
					} catch (IOException ioe) {
						System.err.println("Error al cerrar el archivo");
					}
				}
			}

		}
	}
}
