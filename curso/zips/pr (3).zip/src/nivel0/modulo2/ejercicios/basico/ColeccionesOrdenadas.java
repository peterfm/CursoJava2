import java.util.*;

public class ColeccionesOrdenadas {
	public static void main(String args[]) {
		Set s = new TreeSet(); // Ordena los elementos que contiene
		s.add(new Persona(123, 10));
		s.add(new Persona(456, 2));
		s.add(new Persona(789, 20));
		s.add(new Persona(012, 50));
		s.add(new Persona(345, 45));
		s.add(new Persona(678, 15));

		for (Object obj : s) 
			System.out.println(obj);
	
		System.out.println("******************");
		List l = new ArrayList(); 
		l.add(new Persona(123, 10));
		l.add(new Persona(456, 2));
		l.add(new Persona(789, 20));
		l.add(new Persona(012, 50));
		l.add(new Persona(345, 45));
		l.add(new Persona(678, 15));

		Collections.sort(l, new ComparadorPersonaPorEdadAsc());
		for (Object obj : l) 
			System.out.println(obj);


		System.out.println("******************");
		Collections.sort(l, new ComparadorPersonaPorEdadDesc());
		for (Object obj : l) 
			System.out.println(obj);

		System.out.println("******************");
		/******************* Clases anónimas ******************/
		// Clase anónima sin referencia
		Collections.sort(l, new Comparator() {
		   public int compare(Object obja, Object objb) {
      		if (obja instanceof Persona && objb instanceof Persona) {
		         Persona a = (Persona) obja;
      		   Persona b = (Persona) objb;

		         if (a.edad > b.edad)
      		      return 1;
		         else if (a.edad < b.edad)
      		      return -1;
		      }
		      return 0; // Son iguales o (a o b no son Persona)
				}	
		});
		for (Object obj : l) 
			System.out.println(obj);

		System.out.println("******************");
		// Clase anónima con referencia
		Comparator comparador = new Comparator() {
		   public int compare(Object obja, Object objb) {
      		if (obja instanceof Persona && objb instanceof Persona) {
		         Persona a = (Persona) obja;
      		   Persona b = (Persona) objb;

		         if (a.edad > b.edad)
      		      return 1;
		         else if (a.edad < b.edad)
      		      return -1;
		      }
		      return 0; // Son iguales o (a o b no son Persona)
				}	
		};

		Collections.sort(l, comparador);
		for (Object obj : l) 
			System.out.println(obj);


	}
}

class ComparadorPersonaPorEdadAsc implements Comparator {
	public int compare(Object obja, Object objb) {
		if (obja instanceof Persona && objb instanceof Persona) {
			Persona a = (Persona) obja;
			Persona b = (Persona) objb;

			if (a.edad > b.edad)
				return 1; 
			else if (a.edad < b.edad)
				return -1;
		}

		return 0; // Son iguales o (a o b no son Persona)
	}	
}

class ComparadorPersonaPorEdadDesc implements Comparator {
	public int compare(Object obja, Object objb) {
		if (obja instanceof Persona && objb instanceof Persona) {
			Persona a = (Persona) obja;
			Persona b = (Persona) objb;

			if (a.edad > b.edad)
				return -1; 
			else if (a.edad < b.edad)
				return 1;
		}

		return 0; // Son iguales o (a o b no son Persona)
	}	
}

class Persona implements Comparable {
	public int dni;
	public int edad;
	public Persona(int dni, int edad) { this.dni = dni; this.edad = edad; }
	public String toString() { 
		return "[dni = " + dni + 
			", edad =" +  edad + "]"; 
	}
	public int compareTo(Object obj) {
		if (obj instanceof Persona) {
			if (edad > ((Persona) obj).edad)
				return 1; // Yo soy mayor que obj
			else if (edad < ((Persona) obj).edad)
				return -1; // Yo soy menor que obj
		}
		
		return 0; // Yo soy igual a obj o no soy una persona
	}
}





