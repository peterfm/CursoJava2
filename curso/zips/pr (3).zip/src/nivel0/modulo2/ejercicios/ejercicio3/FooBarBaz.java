public class FooBarBaz {
	public static void main(String args[]) {
		for (int i = 1; i <= 16; i++) {
			String linea = i + ". ";

			if (i % 3 == 0)
				linea += "foo ";
			if (i % 5 == 0)
				linea += "bar ";				
			if (i % 7 == 0)
				linea += "baz ";

			System.out.println(linea.trim());
		}
	}
}
