import java.util.*;

public class Colecciones {
	public static void main(String args[]) {
		Set<Employee> empleados = new HashSet<Employee>();
		empleados.add(new Director(1, "Juan", 5000, null, null, 0.0));
		empleados.add(new Director(2, "María", 9000, null, null, 0.0));
		empleados.add(new Manager(3, "Ana", 3000, null, null));
		empleados.add(new Manager(4, "Rodolfo", 1000, null, null));
		empleados.add(new Manager(4, "Yo", 1000, null, null)); // No lo agrega por id
		empleados.add(new Employee(5, "Pedro", 7000, null));

		imprimir(empleados);

		System.out.println("******************");
		List<Employee> listaEmpleados = new ArrayList<Employee>(empleados);
		Collections.sort(listaEmpleados, new OrdenarEmployeePorSalary());
		imprimir(listaEmpleados);
	}

	public static void imprimir(Collection<Employee> empleados) {
		for (Employee e: empleados) {
			System.out.println("id = " + e.id);
			System.out.println("name = " + e.name);
			System.out.println("salary = " + e.salary);
			System.out.println("birthDate = " + e.birthDate);
			if (e instanceof Manager)
				System.out.println("department = " + ((Manager)e).department);
			if (e instanceof Director)
				System.out.println("carAllowance = " + ((Director)e).carAllowance);
			System.out.println();
		}	
	}
}

class OrdenarEmployeePorSalary implements Comparator<Employee> {
	public int compare(Employee a, Employee b) {
		if (a.salary > b.salary)
			return 1;
		else if (a.salary < b.salary)
			return -1;
		else
			return 0;		
	}
}

class Employee {
	protected int id;
   protected String name; // Puede acceder él, el paquete y sus hijos
   protected double salary;
   protected Date birthDate;
	
	public int hashCode() { return id; }
	public boolean equals(Object obj) { 
		if (obj instanceof Employee) 
			return ((Employee) obj).id == id;
		else
			return false;
	}

   public Employee(int id, String name, double salary, Date birthDate) {
		this.id = id;
      this.name = name;
      this.salary = salary;
      this.birthDate = birthDate;
   }

}

class Manager extends Employee {
   public String department;

   public Manager(
			int id, 
			String name, 
			double salary, 
			Date birthDate, 
			String department) {

		super(id, name, salary, birthDate);
      this.department = department;
   }

}

class Director extends Manager {
   protected double carAllowance;

	public Director(
			int id, 
			String name, 
			double salary, 
			Date birthDate, 
			String department,
			double carAllowance) {
		
		super(id, name, salary, birthDate, department);
		this.carAllowance = carAllowance;
	}

}

