public class Calculadoras {
	public static void main(String args[]) {
		try {
			if (args != null && args.length == 3) {
				int a = Integer.parseInt(args[1]);
				int b = Integer.parseInt(args[2]);

				Calculadora calc = new Calculadora();

				if (args[0].toLowerCase().equals("sum")) 
					System.out.println(calc.sumar(a, b));
				else if (args[0].toLowerCase().equals("res"))
					System.out.println(calc.restar(a, b));
				else if (args[0].toLowerCase().equals("mul"))
					System.out.println(calc.multiplicar(a, b));
				else if (args[0].toLowerCase().equals("div"))
					System.out.println(calc.dividir(a, b));

			} else {
				System.err.println("El uso adecuado del programa es: ");
				System.err.println("java Calculadora op num num");
				System.err.println("Donde:");
				System.err.println("\top = sum|res|mul|div");
				System.err.println("\tnum = número natural");
			}
		} catch (DesbordamientoEnteroException dee) {
			System.err.println("El entero " + dee.getValue() + " es más grande de lo permitido: " + Integer.MAX_VALUE);
		} catch (EnteroInvalidoException eie) {
			System.err.println("El valor no es entero");
		} catch (SustraendoInvalidoException si) {
			System.err.println("El sustraendo es inválido");
		} catch (DivisorInvalidoException die) {
			System.err.println("El divisor es inválido");
		} catch (Exception e) {
			System.err.println("No sé qué quieres hacer chaval!");

		}
	}
}

class Calculadora {
	public int sumar(int a, int b) 
			throws DesbordamientoEnteroException, EnteroInvalidoException {
		validar(a); // Llama a validar(int)
		validar(b); // Llama a validar(int)

		long c = (long)a + b; // Llama a validar(long)
		validar(c);
		return (int) c;
	}
	public int restar(int a, int b) throws 
				DesbordamientoEnteroException, 
				EnteroInvalidoException, 
				SustraendoInvalidoException {
		
		validar(a);
		validar(b);

		if (b > a)
			throw new SustraendoInvalidoException();

		return a - b;
	}
	public int dividir(int a, int b) throws 
				DesbordamientoEnteroException,
            EnteroInvalidoException, 
				DivisorInvalidoException {

		validar(a);
		validar(b);

		if (b == 0)
			throw new DivisorInvalidoException();

		return a / b;
	}
	public int multiplicar(int a, int b) 
			throws DesbordamientoEnteroException, EnteroInvalidoException {

		validar(a); // Llama a validar(int)
		validar(b); // Llama a validar(int)

		long c = (long)a * b; // Llama a validar(long)
		validar(c);
		return (int) c;
	}
	public void validar(long a) 
			throws DesbordamientoEnteroException, EnteroInvalidoException {

		if (a > Integer.MAX_VALUE) 
			throw new DesbordamientoEnteroException(a);
		if (a < Integer.MIN_VALUE)
			throw new DesbordamientoEnteroException(a);
			
		validar((int) a);
	}
	public void validar(int a) 
			throws EnteroInvalidoException {

		if (a < 0)
			throw new EnteroInvalidoException();
	}
	public void validar(String a) 
			throws EnteroInvalidoException {

		try {
			validar(Integer.parseInt(a));
		} catch (Exception e) {
			throw new EnteroInvalidoException();
		}
	}

}

abstract class CalculadoraException extends Exception {
	public CalculadoraException() {}
	public CalculadoraException(String msg) { super(msg); }
}

class EnteroInvalidoException extends CalculadoraException {
	public EnteroInvalidoException() {}
	public EnteroInvalidoException(String msg) { super(msg); }
}
class SustraendoInvalidoException extends CalculadoraException {}
class DivisorInvalidoException extends CalculadoraException {}
class DesbordamientoEnteroException extends EnteroInvalidoException {
	private long value;
	public DesbordamientoEnteroException(long value) {
		this(null, value);
	}
	public DesbordamientoEnteroException(String msg, long value) {
		super(msg);
		this.value = value;
	}
	public long getValue() { return value; }
}





