public class CalculadorasNatural {
	public static void main(String args[]) {
		try {
			if (args != null && args.length == 3) {
				Natural a = new Natural(args[1]);
				Natural b = new Natural(args[2]);

				if (args[0].toLowerCase().equals("sum")) 
					System.out.println(a.sumar(b));
				else if (args[0].toLowerCase().equals("res"))
					System.out.println(a.restar(b));
				else if (args[0].toLowerCase().equals("mul"))
					System.out.println(a.multiplicar(b));
				else if (args[0].toLowerCase().equals("div"))
					System.out.println(a.dividir(b));

			} else {
				System.err.println("El uso adecuado del programa es: ");
				System.err.println("java Calculadora op num num");
				System.err.println("Donde:");
				System.err.println("\top = sum|res|mul|div");
				System.err.println("\tnum = número natural");
			}
		} catch (DesbordamientoEnteroException dee) {
			System.err.println("El entero " + dee.getValue() + " es más grande de lo permitido: " + Integer.MAX_VALUE);
		} catch (EnteroInvalidoException eie) {
			System.err.println("El valor no es entero");
		} catch (SustraendoInvalidoException si) {
			System.err.println("El sustraendo es inválido");
		} catch (DivisorInvalidoException die) {
			System.err.println("El divisor es inválido");
		} catch (Exception e) {
			System.err.println("No sé qué quieres hacer chaval!");

		}
	}
}

class Natural {
	private int valor;

	public Natural(long valor)
			throws DesbordamientoEnteroException, EnteroInvalidoException {

		validar(valor);
		this.valor = (int) valor;     
	}
	
	public Natural(int valor) throws EnteroInvalidoException {
		validar(valor);
		this.valor = valor;
	}

	public Natural(String valor) throws EnteroInvalidoException {
		validar(valor);
		this.valor = Integer.parseInt(valor);
   }

	public int getValor() { return valor; }

	public Natural sumar(Natural nat) throws EnteroInvalidoException {
		return new Natural((long)valor + nat.getValor());
	}

	public Natural restar(Natural nat) 
			throws EnteroInvalidoException, SustraendoInvalidoException {
		if (valor < nat.getValor())
			throw new SustraendoInvalidoException();

		return new Natural(valor - nat.getValor());
	}

	public Natural multiplicar(Natural nat) throws EnteroInvalidoException {
		return new Natural((long)valor * nat.getValor());
	}

	public Natural dividir(Natural nat) 
			throws EnteroInvalidoException, DivisorInvalidoException {
		if (nat.getValor() == 0)
			throw new DivisorInvalidoException();

		return new Natural(valor / nat.getValor());
	}


	public String toString() {
		return Integer.toString(valor);
	}

   public void validar(long a)
         throws DesbordamientoEnteroException, EnteroInvalidoException {

      if (a > Integer.MAX_VALUE)
         throw new DesbordamientoEnteroException(a);
      if (a < Integer.MIN_VALUE)
         throw new DesbordamientoEnteroException(a);

      validar((int) a);
   }
   public void validar(int a)
         throws EnteroInvalidoException {

      if (a < 0)
         throw new EnteroInvalidoException();
   }
   public void validar(String a)
         throws EnteroInvalidoException {

      try {
         validar(Integer.parseInt(a));
      } catch (Exception e) {
         throw new EnteroInvalidoException();
      }
   }

}

class EnteroInvalidoException extends CalculadoraException {
   public EnteroInvalidoException() {}
   public EnteroInvalidoException(String msg) { super(msg); }
}
class SustraendoInvalidoException extends CalculadoraException {}
class DivisorInvalidoException extends CalculadoraException {}
class DesbordamientoEnteroException extends EnteroInvalidoException {
   private long value;
   public DesbordamientoEnteroException(long value) {
      this(null, value);
   }
   public DesbordamientoEnteroException(String msg, long value) {
      super(msg);
      this.value = value;
   }
   public long getValue() { return value; }
}

