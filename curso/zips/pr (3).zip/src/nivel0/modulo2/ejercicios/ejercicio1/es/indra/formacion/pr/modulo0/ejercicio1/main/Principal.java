package es.indra.formacion.pr.modulo0.ejercicio1.main;

import es.indra.formacion.pr.modulo0.ejercicio1.modelo.Persona;

public class Principal {
	public static void main(String args[]) {
		Persona p = new Persona(180f, 80f);
		System.out.println(p.getAltura());		
		System.out.println(p.getPeso());		
		System.out.println(p.getDensidad());		
	}
}
