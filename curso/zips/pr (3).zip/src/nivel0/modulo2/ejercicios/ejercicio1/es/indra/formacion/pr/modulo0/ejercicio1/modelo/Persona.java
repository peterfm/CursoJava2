package es.indra.formacion.pr.modulo0.ejercicio1.modelo;

/**
 * Esta clase representa una Persona del Sistema
 * @author Rodolfo
 * @version 1.0
 */
public class Persona {
	private float peso;
	private float altura;

	/**
	 * Este es el constructor de la clase
	 * @param p float Peso de la persona
	 * @param a float Altura de la persona
	 */
	public Persona(float p, float a) {
		peso = p;
		altura = a;
	}

	public void setPeso(float p) { 
		peso = p;
	}

	public void setAltura(float a) { 
		altura = a;
	}

	/**
	 * Este es el setter de peso, si el peso es mayor que 0 no lo define
	 * @return float Peso de la persona en libras
	 */ 
	public float getPeso() {
		return peso;
	}

	public float getAltura() {
		return altura;
	}
	
	public float getDensidad() {
		return peso / altura;
	}
}
