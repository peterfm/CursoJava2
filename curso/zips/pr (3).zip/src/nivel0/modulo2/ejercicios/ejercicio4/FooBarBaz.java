public class FooBarBaz {
	public static final int MAX = 16;
	public static void main(String args[]) {
		String[][] lineas = new String[MAX][3];

		for (int i = 1; i <= MAX; i++) {
			if (i % 3 == 0)
				lineas[i - 1][0] = new String("foo ");
			if (i % 5 == 0)
				lineas[i - 1][1] = "bar ";
			if (i % 7 == 0)
				lineas[i - 1][2] = "baz ";
		}


		imprimir(lineas);
	}

	public static void imprimir(String[][] lineas) {
		for (int i = 1; i <= MAX; i++) {
			String l = i + ". " +
				((lineas[i - 1][0]!=null)?lineas[i - 1][0]:"    ") +
				((lineas[i - 1][1]!=null)?lineas[i - 1][1]:"    ") +
				((lineas[i - 1][2]!=null)?lineas[i - 1][2]:"    ");
			System.out.println(l);	
		}
	}
}
