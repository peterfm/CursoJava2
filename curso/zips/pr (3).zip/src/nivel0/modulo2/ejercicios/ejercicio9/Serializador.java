import java.util.*;
import java.io.*;

public class Serializador<T>  {
	private String archivo;

	public static void main(String args[]) throws Exception {
		Scanner scanner = new Scanner(System.in);

		// Pidiendo datos de la Persona al usuario
		System.out.print("Archivo? ");
		String archivo = scanner.nextLine();
	
		System.out.print("Altura? ");
		String saltura = scanner.nextLine();
		float altura = Float.parseFloat(saltura);

		System.out.print("Peso? ");
		String speso = scanner.nextLine();
		float peso = Float.parseFloat(speso);

		Persona p = new Persona(altura, peso);
		Serializador<Persona> s = new Serializador<Persona>(archivo);

		// Serializando el objeto "p"
		s.serializar(p);
		
		// Deserializando el objeto
		p = s.deserializar();
		System.out.println(p);
	}

	public Serializador(String archivo) {
		this.archivo = archivo;
	}

	public void serializar(T p) throws Exception {
		FileOutputStream fos = new FileOutputStream(archivo);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(p);
		fos.close();
	}

	public T deserializar() throws Exception {
		FileInputStream fis = new FileInputStream(archivo);
		ObjectInputStream ois = new ObjectInputStream(fis);

		return (T) ois.readObject();
	}

}

class Persona implements Serializable {
	private float altura;
	private float peso;
	
	public Persona(float altura, float peso) {
		this.altura = altura;
		this.peso = peso;
	}

	public float getAltura() { return altura; }
	public float getPeso() { return peso; }
	public float getDensidad() { return peso * altura; }
	public void setAltura(float altura) { this.altura = altura; }
	public void setPeso(float peso) { this.peso = peso; }
	public String toString() {
		return "[ altura = " + altura + 
			", peso = " + peso + 
			", densidad = " + getDensidad() + "]";
	}
}
