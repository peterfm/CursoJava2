public class Referencias {
	public static void main(String args[]) {
		Persona a = new Persona(160f, 60f);
		Persona b = new Persona(170f, 70f);
		Persona c = new Persona(180f, 80f);

		imprimir(a);
		imprimir(b);
		imprimir(c);	

		a = b;
		c = b;

		a.setAltura(200f);
		a.setPeso(100f);
		
		imprimir(a);
		imprimir(b);
		imprimir(c);	

		// Marcando referencias a null para que las instancias sean descartables
		a = b = c = null;

	}


	public static void imprimir(Persona p) {
		System.out.println();
		System.out.println("Altura = " + p.getAltura());
		System.out.println("Peso = " + p.getPeso());
		System.out.println("Densidad = " + p.getDensidad());
	}
}
