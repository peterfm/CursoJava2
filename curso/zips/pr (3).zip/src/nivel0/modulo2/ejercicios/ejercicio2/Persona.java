public class Persona {
        private float peso;
        private float altura;

        public Persona(float peso, float altura) {
                this.peso = peso;
                this.altura = altura;
        }

        public Persona(float peso) {
			this(peso, 0f);
        }

        public Persona() {
                this(0f);
        }

        public void setPeso(float peso) {
                this.peso = peso;
        }

        public void setAltura(float altura) {
                this.altura = altura;
        }

        public float getPeso() {
                return this.peso;
        }

        public float getAltura() {
                return this.altura;
        }

        public float getDensidad() {
                return peso / altura;
        }
}

