INSERT INTO  persona ( nombre,apellido, fecha_nacimiento, altura) VALUES ('Juan','Perez','1980-01-03',180);
INSERT INTO  persona ( nombre,apellido, fecha_nacimiento, altura) VALUES ('Maria','Gonzalez','1970-04-20',160);
INSERT INTO  persona ( nombre,apellido, fecha_nacimiento, altura) VALUES ('Pedro','Garcia','1971-05-18',170);

INSERT INTO ordenador(persona_id, nombre, serial) VALUES(1, 'uno', '123');
INSERT INTO ordenador(persona_id, nombre, serial) VALUES(2, 'dos', '456');
INSERT INTO ordenador(persona_id, nombre, serial) VALUES(3, 'tres', '789');