package es.indra.formacion.pr.spring.dao;

import es.indra.formacion.pr.persistence.model.Persona;

public class PersonaDao extends BaseDao<Persona, Integer> implements IPersonaDao {
}
