package es.indra.formacion.pr.persistence.dao;

import es.indra.formacion.pr.persistence.model.Persona;

public interface IPersonaDao extends IDao<Persona, Integer>{
}
