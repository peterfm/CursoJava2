package es.indra.formacion.pr.persistence.dao;

import es.indra.formacion.pr.persistence.model.Ordenador;

public interface IOrdenadorDao extends IDao<Ordenador, Integer> {

}
