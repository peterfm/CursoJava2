curso_pr_persistence
====================

Curso de Persistencia (JPA/Hibernate) del PR
